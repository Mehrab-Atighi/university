ISLR
====

An Introduction to Statistical Learning with Applications in R

by Gareth James, Daniela Witten, Trevor Hastie and Robert Tibshirani
